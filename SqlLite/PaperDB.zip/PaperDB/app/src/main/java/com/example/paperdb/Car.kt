package com.example.paperdb

data class Car( var name : String,
            var model : String)